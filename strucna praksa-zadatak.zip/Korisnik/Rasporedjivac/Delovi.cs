﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rasporedjivac
{
    public class Delovi
    {
        public int[] deo1 = null;
        public int[] deo2 = null;

         public Delovi(int[] d1, int[] d2)
        {
            deo1 = d1;
            deo2 = d2;
        
        }
    }
}
